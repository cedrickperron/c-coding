#!/bin/bash

sbatch run_random_1.sh
sbatch run_random_4.sh
sbatch run_random_16.sh
sbatch run_random_32.sh
