#ifndef INIT_H
#define INIT_H

void Init_CalcStaticScales(void);

#endif
