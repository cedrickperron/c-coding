#ifndef SCHROEDINGER_H
#define SCHROEDINGER_H



double Schroedinger_GetBoundState(NumerovParams *D_Params, NumerovParams *N_Params_f, NumerovParams *N_Params_b, double yf, double yb);


//void ReadInParams(char *input_file);

//void RecordParams(NumerovParams N_Params_f, NumerovParams N_Params_b);

//void ReadIn_N_Params(char *input_file_name, NumerovParams *N_Params_f, NumerovParams *N_Params_b);

//void RecordResults(DynamicParams D_Params, NumerovParams N_Params_f, NumerovParams N_Params_b, double *yf, double *yb);



#endif
