#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "params.h"
#include "numerov_params.h"
#include "init.h"
#include "schroedinger.h"
#include "vector_mtx.h"

void ReadInParams(char *input_file);

void ReadIn_N_Params(char *input_file_name, NumerovParams *N_Params_f, NumerovParams *N_Params_b);

void RecordParams(NumerovParams N_Params_f, NumerovParams N_Params_b);

void RecordResults(DynamicParams D_Params,NumerovParams N_Params_f, NumerovParams N_Params_b,double *yf, double *yb);

Params PARAM_DATA;


int main(int argc, char **argv)
{
 DynamicParams D_Params;
 NumerovParams N_Params_f;
 NumerovParams N_Params_b;

 double *yf, *yb;

 ReadInParams(argv[1]); //Reads in the initial data. This is the first input file
 
 ReadIn_N_Params(argv[2], &N_Params_f, &N_Params_b);

 Init_CalcStaticScales(); //Get the Energy and Length Scales

 //Record The parameters
 RecordParams(N_Params_f, N_Params_b);

 /* Will be implemented in the next assignment */
 /*

 // Allocate memory for the forward WF yf
 yf = vector_malloc(N_Params_f.nmax+1);
 // Allocate memory for the backward WF yb
 yb = vector_malloc(N_Params_b.nmax+1);
  
 Schroedinger_GetBoundState(&D_Params, &N_Params_f, &N_Params_b, yf, yb);
 RecordResults(D_Params, N_Params_f, N_Params_b, yf, yb);
 */
 /* Next assignment */
 return 0;
}//main

void ReadInParams(char *input_file)
{
 FILE *input;
 double x;
 int ix;
 char *mass_unit;
 double mass, nucA, nucZ;
 int ell;
 input = fopen(input_file, "r");
 
 
 fscanf(input, "%le", &mass);  //TEST
 mass /= hbarc;
 PARAM_DATA.mass = mass; //SHOULD BE IN file params.h (26 ASS 3)

 mass_unit = (char *)malloc(sizeof(char)*10);
 
 fscanf(input, "%s", mass_unit);
 PARAM_DATA.mass_unit = mass_unit;

 if(strcmp(mass_unit, "eV")==0) {PARAM_DATA.length_unit = "nm";}
 else if(strcmp(mass_unit, "MeV")==0) {PARAM_DATA.length_unit = "fm";}
 else {
  fprintf(stderr, "ReadInParams: %s is an unknown unit. \n", mass_unit);
  fprintf(stderr, "Known units are eV and MeV. \n");
  fprintf(stderr, "Exiting. \n");
  exit(0);
}
 fscanf(input, "%d", &ell);
 PARAM_DATA.ell = ell;

 fscanf(input, "%le", &nucA);
 PARAM_DATA.nucA = nucA;
 
 fscanf(input, "%le", &nucZ);
 PARAM_DATA.nucZ = nucZ;

 fclose(input);

 return;
}// ReadInParams

void RecordParams(NumerovParams N_Params_f, NumerovParams N_Params_b)
{
 double x;
 int i;
 FILE *output;

 output = fopen("params_data.dat", "w");
 
 fprintf(output, "mass = %le \n", PARAM_DATA.mass*hbarc);
 fprintf(output, "Ea = %le \n", PARAM_DATA.Ea*hbarc);
 fprintf(output, "r0 = %le \n", PARAM_DATA.r0);
 fprintf(output, "ka = %le \n", PARAM_DATA.ka*hbarc);
 fprintf(output, "ell = %d \n", PARAM_DATA.ell);
 fprintf(output, "x0 = %le \n", PARAM_DATA.x0);
 fprintf(output, "nucA = %le \n", PARAM_DATA.nucA);
 fprintf(output, "nucZ = %le \n", PARAM_DATA.nucZ);
 fprintf(output, "nmaxf = %d \n", N_Params_f.nmax);
 fprintf(output, "nmaxb = %d \n", N_Params_b.nmax);

 fclose(output);
 return;
}// RecordParams

void ReadIn_N_Params(char *input_file_name, NumerovParams *N_Params_f, NumerovParams *N_Params_b)
{
 FILE *input_file;
 double x;
 int ix;
 int nmax;

 input_file = fopen(input_file_name, "r");
 
 fscanf(input_file, "%d", &nmax);
 N_Params_f->nmax = nmax;
 
 fscanf(input_file, "%d", &nmax);
 N_Params_b->nmax = nmax; 

 fclose(input_file);

 return;
}//ReadIn_N_Params

void RecordResults(DynamicParams D_Params, NumerovParams N_Params_f, NumerovParams N_Params_b, double *yf, double *yb)
{
 //Next Assignment
 return;
}// RecordResults


