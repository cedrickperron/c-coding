# Usage for HW6

## Compilation

`make`  will both generate an executable (laplacesolver) from the source files.

## Running

`./1dlaplacesolver -h` will print the information about the function

`make run`  will print the output of ./1dlaplacesolver

### CLEANING

To safely remove all executables and .o files, run `make clean` in terminal.
