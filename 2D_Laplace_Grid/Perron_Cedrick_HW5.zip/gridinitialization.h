// gridinitialization.h
#ifndef GRIDINITIALIZATIONH
#define GRIDINITIALIZATIONH

#include <rarray>

rarray<double, 2> create_NbyN_array(int N, double fill_value);

#endif
