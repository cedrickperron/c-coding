# ReadMe

Author: Cedrick Perron
Email address: cedrick.perron@mail.utoronto.ca

Compiler: gcc 

## Project overview
Find the optimal launch angle given the speed for a maximum horizontal displacement

## Physics background
See Assignment 1 information

##Description of files

-"angle.cpp": Main executable, ask the input of v by the user and find the optimal angle and horizontal distance. There we iterate over every angle, solve the maximum time before which y<0 and use this time to solve for x_max. We then take the largest x_max out of every angle iterated over.


## Usage
Usage is described in `Usage.md`.

