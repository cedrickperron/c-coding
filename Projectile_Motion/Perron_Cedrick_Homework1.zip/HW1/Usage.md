Run:

g++ -o angle_test angle.cpp -I. -lm
./angle_test



